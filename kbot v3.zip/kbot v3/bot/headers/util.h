#pragma once
#include <linux/ip.h>
#include "includes.h"

#define PAD_RIGHT 1
#define PAD_ZERO 2
#define PRINT_BUF_LEN 12

int util_encryption(char *string);
void util_trim(char *str);
int util_sockprint(int sock, char *formatStr, ...);
int util_memsearch(char *, int, char *, int);
ipv4_t util_local_addr(void);
uint16_t checksum_generic(uint16_t *, uint32_t);
uint16_t checksum_tcpudp(struct iphdr *, void *, uint16_t, int);
