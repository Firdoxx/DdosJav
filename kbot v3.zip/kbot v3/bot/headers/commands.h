#pragma once
#include "includes.h"

void commands_process(int argc, unsigned char **argv);
void commands_parse();
