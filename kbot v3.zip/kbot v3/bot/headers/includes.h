#pragma once
#include <stdint.h>

#define INET_ADDR(o1,o2,o3,o4) (htonl((o1 << 24) | (o2 << 16) | (o3 << 8) | (o4 << 0)))

typedef uint32_t ipv4_t;
typedef char BOOL;
ipv4_t LOCAL_ADDR;
