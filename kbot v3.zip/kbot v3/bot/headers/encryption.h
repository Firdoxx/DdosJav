#pragma once

extern char encryptstring[512];
extern char decryptstring[512];
extern char dec_buf[512];

#define MAX_ENCS 13
#define TABLE_KEY 1

struct encryptyes{
	char combo[50];
	char decrypt[50];
	uint32_t decrypt32;
};

void add_combo(char *);
void encrypt_array();
void decrypt_by_name(char *);
void encrypt_by_name(char *);
void decrypt_for_recv(char *);

struct encryptyes encrypter[MAX_ENCS];

